sap.ui.require(
    [
        'sap/fe/test/JourneyRunner',
        'programadefidelidade/produtos/test/integration/FirstJourney',
		'programadefidelidade/produtos/test/integration/pages/ProductsList',
		'programadefidelidade/produtos/test/integration/pages/ProductsObjectPage'
    ],
    function(JourneyRunner, opaJourney, ProductsList, ProductsObjectPage) {
        'use strict';
        var JourneyRunner = new JourneyRunner({
            // start index.html in web folder
            launchUrl: sap.ui.require.toUrl('programadefidelidade/produtos') + '/index.html'
        });

       
        JourneyRunner.run(
            {
                pages: { 
					onTheProductsList: ProductsList,
					onTheProductsObjectPage: ProductsObjectPage
                }
            },
            opaJourney.run
        );
    }
);