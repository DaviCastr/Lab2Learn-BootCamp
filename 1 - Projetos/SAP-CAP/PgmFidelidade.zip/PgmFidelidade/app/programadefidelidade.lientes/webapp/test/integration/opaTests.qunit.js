sap.ui.require(
    [
        'sap/fe/test/JourneyRunner',
        'programadefidelidade/lientes/test/integration/FirstJourney',
		'programadefidelidade/lientes/test/integration/pages/CustomersList',
		'programadefidelidade/lientes/test/integration/pages/CustomersObjectPage'
    ],
    function(JourneyRunner, opaJourney, CustomersList, CustomersObjectPage) {
        'use strict';
        var JourneyRunner = new JourneyRunner({
            // start index.html in web folder
            launchUrl: sap.ui.require.toUrl('programadefidelidade/lientes') + '/index.html'
        });

       
        JourneyRunner.run(
            {
                pages: { 
					onTheCustomersList: CustomersList,
					onTheCustomersObjectPage: CustomersObjectPage
                }
            },
            opaJourney.run
        );
    }
);