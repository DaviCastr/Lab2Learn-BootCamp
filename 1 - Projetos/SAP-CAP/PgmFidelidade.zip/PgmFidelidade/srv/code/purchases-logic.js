/**
 * 
 * @On(event = { "CREATE" }, entity = "programaDeFidelidadeSrv.Purchases")
 * @param {cds.Request} request - User information, tenant-specific CDS model, headers and query parameters
 * @param {Function} next - Callback function to the next handler
 */
module.exports = async function(request, next) {
    const { Purchases, Customers } = cds.entities;
    
    // Prosseguir com a criação da compra
    let purchase = await next();

    purchase = await SELECT.one.from(request.entity).where({ID: purchase.ID }) ;

    if (purchase && purchase.purchaseValue && purchase.customer_ID) {
        // Calcular os pontos de recompensa como um décimo do valor da compra
        const rewardPoints = Math.floor(purchase.purchaseValue / 10);

        // Atualizar os pontos de recompensa na compra
        purchase.rewardPoints = rewardPoints;

        // Atualizar o valor total de compras e os pontos de recompensa totais do cliente relacionado
        const customerUpdate = {
            totalPurchaseValue: { '+=': purchase.purchaseValue },
            totalRewardPoints: { '+=': rewardPoints }
        };

        await UPDATE('programaDeFidelidadeSrv.Customers.drafts').set(customerUpdate).where({ ID: purchase.customer_ID });
    }

    return purchase;
}