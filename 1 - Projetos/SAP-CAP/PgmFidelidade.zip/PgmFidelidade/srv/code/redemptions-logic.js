/**
 * 
 * @On(event = { "CREATE" }, entity = "programaDeFidelidadeSrv.Redemptions")
 * @param {cds.Request} request - User information, tenant-specific CDS model, headers and query parameters
 * @param {Function} next - Callback function to the next handler
 */
module.exports = async function(request, next) {
    // Obter os dados da requisição
    const { data } = request;
    if (!data || !data.customer_ID || !data.redeemedAmount) {
        // Se os dados necessários não estiverem presentes, não prossiga
        return next();
    }

    // Obter as entidades globais necessárias
    const { Customers } = cds.entities;

    // Buscar o cliente associado à redenção
    const customer = await SELECT.one.from(Customers).where({ ID: data.customer_ID });

    if (!customer) {
        // Se o cliente não for encontrado, não prossiga
        return next();
    }

    // Verificar se o cliente tem pontos de recompensa suficientes
    if (customer.totalRewardPoints < data.redeemedAmount) {
        // Se não houver pontos suficientes, lançar um erro
        return request.error(400, 'Pontos de recompensa insuficientes para a redenção.');
    }

    // Deduzir o valor da redenção dos pontos totais de recompensa do cliente
    customer.totalRewardPoints -= data.redeemedAmount;

    // Adicionar o valor da redenção aos pontos totais resgatados do cliente
    customer.totalRedeemedRewardPoints += data.redeemedAmount;

    // Atualizar os dados do cliente
    await UPDATE(Customers).set({
        totalRewardPoints: customer.totalRewardPoints,
        totalRedeemedRewardPoints: customer.totalRedeemedRewardPoints
    }).where({ ID: data.customer_ID });

    // Continuar para o próximo manipulador
    return next();
}