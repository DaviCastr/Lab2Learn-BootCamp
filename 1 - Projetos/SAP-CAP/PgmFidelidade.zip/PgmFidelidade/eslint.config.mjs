import cds from '@sap/cds/eslint.config.mjs'
export default [ ...cds.recommended ]
